export const MODAL_OPEN = 'MODAL_OPEN';
export const MODAL_CLOSE = 'MODAL_CLOSE';
export const PHOTO_ON_LOAD = 'PHOTO_ON_LOAD';